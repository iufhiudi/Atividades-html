const btMostrar = document.getElementById("btMostrar");

btMostrar.addEventListener("click", () => {
  const inMedicamento = document.getElementById("inMedicamento");
  const inPreco = document.getElementById("inPreco");
  const outMedicamento = document.getElementById("outMedicamento");
  const outPromocao = document.getElementById("outPromocao");

  const medicamento = inMedicamento.value;
  const preco = Number(inPreco.value);

  // Cálculo da promoção: 2 unidades com desconto dos centavos
  const precoTotal = 2 * preco;
  const precoPromocional = Math.floor(precoTotal);

  outMedicamento.textContent = `Promoção de ${medicamento}`;
  outPromocao.textContent = `Leve 2 por apenas R$: ${precoPromocional.toFixed(2)}`;
});