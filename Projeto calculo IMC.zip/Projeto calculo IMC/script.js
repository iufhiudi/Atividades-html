const lista = [];

document.getElementById("imcForm").addEventListener("submit", function(event) {
  event.preventDefault();

  const nome = document.getElementById("nome").value;
  const sexo = document.getElementById("sexo").value;
  const peso = parseFloat(document.getElementById("peso").value);
  const altura = parseFloat(document.getElementById("altura").value);

  const imc = (peso / (altura * altura)).toFixed(1);
  const { condicao, imcMin, imcMax } = classificarCondicao(imc, sexo);
  const pesoIdealMin = (imcMin * altura * altura).toFixed(1);
  const pesoIdealMax = (imcMax * altura * altura).toFixed(1);
  const diferenca = calcularDiferenca(peso, imc, imcMin, imcMax, altura);

  const resultado = {
    nome, sexo, peso, altura, imc, condicao, diferenca
  };

  lista.push(resultado);
  mostrarResultados();
});

function classificarCondicao(imc, sexo) {
  imc = parseFloat(imc);
  if (sexo === "feminino") {
    if (imc < 19.1) return { condicao: "Abaixo do peso", imcMin: 19.1, imcMax: 25.8 };
    if (imc <= 25.8) return { condicao: "No peso normal", imcMin: 19.1, imcMax: 25.8 };
    if (imc <= 27.3) return { condicao: "Marginalmente acima do peso", imcMin: 19.1, imcMax: 25.8 };
    if (imc <= 32.3) return { condicao: "Acima do peso ideal", imcMin: 19.1, imcMax: 25.8 };
    return { condicao: "Obeso", imcMin: 19.1, imcMax: 25.8 };
  } else {
    if (imc < 20.7) return { condicao: "Abaixo do peso", imcMin: 20.7, imcMax: 26.4 };
    if (imc <= 26.4) return { condicao: "No peso normal", imcMin: 20.7, imcMax: 26.4 };
    if (imc <= 27.8) return { condicao: "Marginalmente acima do peso", imcMin: 20.7, imcMax: 26.4 };
    if (imc <= 31.1) return { condicao: "Acima do peso ideal", imcMin: 20.7, imcMax: 26.4 };
    return { condicao: "Obeso", imcMin: 20.7, imcMax: 26.4 };
  }
}

function calcularDiferenca(pesoAtual, imc, imcMin, imcMax, altura) {
  const pesoIdealMin = imcMin * altura * altura;
  const pesoIdealMax = imcMax * altura * altura;

  if (imc < imcMin) {
    return `Precisa ganhar ${(pesoIdealMin - pesoAtual).toFixed(1)} kg para o peso normal.`;
  } else if (imc > imcMax) {
    return `Precisa perder ${(pesoAtual - pesoIdealMax).toFixed(1)} kg para o peso normal.`;
  } else {
    return `Peso dentro da faixa normal.`;
  }
}

function mostrarResultados() {
  const resultadoEl = document.getElementById("resultado");
  resultadoEl.innerHTML = "";
  lista.forEach(pessoa => {
    const item = document.createElement("li");
    item.textContent = `${pessoa.nome} (${pessoa.sexo}) - IMC: ${pessoa.imc} - ${pessoa.condicao} - ${pessoa.diferenca}`;
    resultadoEl.appendChild(item);
  });
}