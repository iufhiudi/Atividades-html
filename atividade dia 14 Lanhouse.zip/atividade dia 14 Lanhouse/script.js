const btCalcular = document.getElementById("btCalcular");

btCalcular.addEventListener("click", () => {
  const inValor = document.getElementById("inValor");
  const inTempo = document.getElementById("inTempo");
  const outValor = document.getElementById("outValor");

  const valor15min = Number(inValor.value);
  const tempo = Number(inTempo.value);

  // Arredondar para cima a quantidade de blocos de 15 minutos
  const blocos = Math.ceil(tempo / 15);
  const total = blocos * valor15min;

  outValor.textContent = `Valor a Pagar R$: ${total.toFixed(2)}`;
});
