const DISTANCIA_KM = 120;
const VALOR_PEDAGIO = 20;

const veiculos = [];
let inicioProcesso = null;
let finalProcesso = null;

document.getElementById('formulario').addEventListener('submit', function(e) {
  e.preventDefault();

  const placa = document.getElementById('placa').value;
  const entrada = document.getElementById('entrada').value;
  const saida = document.getElementById('saida').value;

  const horaEntrada = converterHoraParaMinutos(entrada);
  const horaSaida = converterHoraParaMinutos(saida);
  const tempoGastoMin = horaSaida - horaEntrada;
  const tempoHoras = tempoGastoMin / 60;

  const velocidade = DISTANCIA_KM / tempoHoras;

  let desconto = 0;
  if (velocidade <= 60) desconto = 0.3;
  else if (velocidade <= 80) desconto = 0.2;
  else if (velocidade <= 100) desconto = 0.1;

  const valorPago = VALOR_PEDAGIO * (1 - desconto);

  const veiculo = {
    placa,
    entrada,
    saida,
    tempo: tempoHoras.toFixed(2),
    velocidade: velocidade.toFixed(2),
    valorPago: valorPago.toFixed(2),
    entradaMin: horaEntrada,
    saidaMin: horaSaida
  };

  veiculos.push(veiculo);

  if (!inicioProcesso || horaEntrada < inicioProcesso) inicioProcesso = horaEntrada;
  if (!finalProcesso || horaSaida > finalProcesso) finalProcesso = horaSaida;

  mostrarTicket(veiculo);

  document.getElementById('formulario').reset();
});

document.getElementById('fecharCaixa').addEventListener('click', function() {
  if (veiculos.length === 0) return;

  const velocidades = veiculos.map(v => parseFloat(v.velocidade));
  const valores = veiculos.map(v => parseFloat(v.valorPago));

  const menorVelocidade = Math.min(...velocidades).toFixed(2);
  const maiorVelocidade = Math.max(...velocidades).toFixed(2);
  const mediaVelocidade = (velocidades.reduce((a, b) => a + b, 0) / velocidades.length).toFixed(2);
  const totalValores = valores.reduce((a, b) => a + b, 0).toFixed(2);

  const relatorioHTML = `
    <p>Menor velocidade registrada: ${menorVelocidade} km/h</p>
    <p>Maior velocidade registrada: ${maiorVelocidade} km/h</p>
    <p>Média das velocidades: ${mediaVelocidade} km/h</p>
    <p>Total arrecadado: R$ ${totalValores}</p>
    <p>Hora de início do processamento: ${converterMinutosParaHora(inicioProcesso)}</p>
    <p>Hora de fim do processamento: ${converterMinutosParaHora(finalProcesso)}</p>
  `;

  document.getElementById('relatorio').innerHTML = relatorioHTML;
});

function mostrarTicket(veiculo) {
  const div = document.createElement('div');
  div.innerHTML = `
    <strong>Placa:</strong> ${veiculo.placa} <br>
    <strong>Entrada:</strong> ${veiculo.entrada} <br>
    <strong>Saída:</strong> ${veiculo.saida} <br>
    <strong>Tempo:</strong> ${veiculo.tempo} horas <br>
    <strong>Velocidade Média:</strong> ${veiculo.velocidade} km/h <br>
    <strong>Valor Pago:</strong> R$ ${veiculo.valorPago} <hr>
  `;
  document.getElementById('tickets').appendChild(div);
}

function converterHoraParaMinutos(horaStr) {
  const [h, m] = horaStr.split(':').map(Number);
  return h * 60 + m;
}

function converterMinutosParaHora(minutos) {
  const h = Math.floor(minutos / 60).toString().padStart(2, '0');
  const m = (minutos % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}