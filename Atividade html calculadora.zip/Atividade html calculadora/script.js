function calcular(operacao) {
    const n1 = parseFloat(document.getElementById("num1").value);
    const n2 = parseFloat(document.getElementById("num2").value);
    let resultado;
  
    if (isNaN(n1) || isNaN(n2) || n1 < 0 || n2 < 0) {
      resultado = "Digite apenas números naturais (0 ou maiores).";
    } else {
      switch (operacao) {
        case '+':
          resultado = n1 + n2;
          break;
        case '-':
          resultado = n1 - n2;
          break;
        case '*':
          resultado = n1 * n2;
          break;
        case '/':
          resultado = n2 === 0 ? "Divisão por zero não é permitida." : n1 / n2;
          break;
      }
    }
  
    document.getElementById("resultado").innerText = "Resultado: " + resultado;
  }