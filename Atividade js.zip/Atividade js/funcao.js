function MensagemdoBotao1() {
    alert("Você clicou no Botão 1")
}

function MensagemdoBotao2() {
    alert("Você clicou no Botão 2")
}

function MensagemdoBotao3() {
    alert("Você clicou no Botão 3")
}