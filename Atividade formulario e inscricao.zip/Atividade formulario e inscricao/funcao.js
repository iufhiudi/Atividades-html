function validarCupom() {
    const cupom = document.getElementById("cupom").value.trim();
    if (cupom === "DESCONTO10") {
      alert("Cupom válido! 10% de desconto aplicado.");
    } else if (cupom) {
      alert("Cupom inválido.");
    } else {
      alert("Por favor, insira um cupom.");
    }
  }
  
  document.getElementById("inscricao-form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Formulário enviado com sucesso!");
  });