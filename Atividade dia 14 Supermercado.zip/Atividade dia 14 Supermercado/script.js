const btVerPromocao = document.getElementById("btVerPromocao");

btVerPromocao.addEventListener("click", () => {
  const inProduto = document.getElementById("inProduto");
  const inPreco = document.getElementById("inPreco");
  const outPromocao = document.getElementById("outPromocao");
  const outDesconto = document.getElementById("outDesconto");

  const produto = inProduto.value;
  const preco = Number(inPreco.value);

  const precoTerceiro = preco / 2;
  const totalPromocao = preco * 2 + precoTerceiro;

  outPromocao.textContent = `${produto} - Promoção: Leve 3 por R$: ${totalPromocao.toFixed(2)}`;
  outDesconto.textContent = `O 3º produto custa apenas R$: ${precoTerceiro.toFixed(2)}`;
});