document.getElementById('formulario').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const valorHora = parseFloat(document.getElementById('valorHora').value);
    const horas = parseFloat(document.getElementById('horasTrabalhadas').value);
    const vt = document.getElementById('valeTransporte').value.trim().toUpperCase();
    const outras = parseFloat(document.getElementById('outrasDeducoes').value || 0);
  
    if (valorHora === 0) {
      alert('Encerrando o sistema...');
      return;
    }
  
    const salarioBruto = valorHora * horas;
  
    // Desconto INSS
    const inss = calcularINSS(salarioBruto);
  
    // Base IRRF
    const baseIR = salarioBruto - inss;
    const irrf = calcularIRPF(baseIR);
  
    // Vale Transporte (6%)
    const descontoVT = vt === 'S' ? salarioBruto * 0.06 : 0;
  
    // Cálculo Final
    const salarioLiquido = salarioBruto - inss - irrf - descontoVT - outras;
  
    document.getElementById('resultado').innerHTML = `
      <h2>Resultado:</h2>
      <p>Salário Bruto: R$ ${salarioBruto.toFixed(2)}</p>
      <p>Desconto INSS: - R$ ${inss.toFixed(2)}</p>
      <p>Desconto IRPF: - R$ ${irrf.toFixed(2)}</p>
      <p>Desconto Vale Transporte: - R$ ${descontoVT.toFixed(2)}</p>
      <p>Outras Deduções: - R$ ${outras.toFixed(2)}</p>
      <hr>
      <h3>Salário Líquido: R$ ${salarioLiquido.toFixed(2)}</h3>
    `;
  });
  
  // Função para cálculo de INSS
  function calcularINSS(salario) {
    let total = 0;
    const faixas = [
      { limite: 1320.00, aliquota: 0.075 },
      { limite: 2571.29, aliquota: 0.09 },
      { limite: 3856.94, aliquota: 0.12 },
      { limite: 7507.49, aliquota: 0.14 }
    ];
  
    let salarioRestante = salario;
    let baseAnterior = 0;
  
    for (const faixa of faixas) {
      if (salario > faixa.limite) {
        total += (faixa.limite - baseAnterior) * faixa.aliquota;
        baseAnterior = faixa.limite;
      } else {
        total += (salario - baseAnterior) * faixa.aliquota;
        break;
      }
    }
  
    return total;
  }
  
  // Função para cálculo de IRPF
  function calcularIRPF(base) {
    let aliquota = 0;
    let deducao = 0;
  
    if (base <= 2112.00) {
      return 0;
    } else if (base <= 2826.65) {
      aliquota = 0.075;
      deducao = 158.40;
    } else if (base <= 3751.05) {
      aliquota = 0.15;
      deducao = 370.40;
    } else if (base <= 4664.68) {
      aliquota = 0.225;
      deducao = 651.73;
    } else {
      aliquota = 0.275;
      deducao = 884.96;
    }
  
    return base * aliquota - deducao;
  }