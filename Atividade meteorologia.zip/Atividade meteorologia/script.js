const apiKey = 'b574594d8acb4f53a23d366105d062e6'

function buscarClima() {
  const cidade = document.getElementById("cidade").value;
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${cidade}&units=metric&lang=pt_br&appid=${apiKey}`;

  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error("Cidade não encontrada");
      return res.json();
    })
    .then(dados => {
      document.getElementById("titulo").textContent = `Tempo ${dados.name}`;
      document.getElementById("temp").textContent = `${dados.main.temp.toFixed(2)} °C`;
      document.getElementById("descricao").textContent = dados.weather[0].description.charAt(0).toUpperCase() + dados.weather[0].description.slice(1);
      document.getElementById("umidade").textContent = `Umidade: ${dados.main.humidity}%`;
      document.getElementById("icone").src = `https://openweathermap.org/img/wn/${dados.weather[0].icon}@2x.png`;
      document.getElementById("resultado").style.display = "block";
    })
    .catch(() => {
      alert("Cidade não encontrada. Verifique o nome e tente novamente.");
      document.getElementById("resultado").style.display = "none";
    });
}